delete from NeighborhoodEntity;

insert into NeighborhoodEntity (id, name, locality, numberOfResidents) values (100, 'Ciudad Salitre', 'Engativá', 100);
insert into NeighborhoodEntity (id, name, locality, numberOfResidents) values (200, 'Chicó Norte', 'Chicó', 800);
insert into NeighborhoodEntity (id, name, locality, numberOfResidents) values (300, 'Kennedy', 'Bosa', 1000);
insert into NeighborhoodEntity (id, name, locality, numberOfResidents) values (400, 'Santa Barbara', 'Usaquén', 300);


delete from NeighborhoodEntity;

insert into NeighborhoodEntity (id, name, locality, numberOfResidents) values (100, 'Ciudad Salitre', 'Engativá', 100);
insert into NeighborhoodEntity (id, name, locality, numberOfResidents) values (200, 'Chicó Norte', 'Chicó', 800);
insert into NeighborhoodEntity (id, name, locality, numberOfResidents) values (300, 'Kennedy', 'Bosa', 1000);
insert into NeighborhoodEntity (id, name, locality, numberOfResidents) values (400, 'Santa Barbara', 'Usaquén', 300);



