import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-registration',
  templateUrl: './profile-registration.component.html',
  styleUrls: ['./profile-registration.component.css']
})
export class ProfileRegistrationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
