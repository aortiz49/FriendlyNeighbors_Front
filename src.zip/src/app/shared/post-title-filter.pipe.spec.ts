import { PostFilterPipe } from './post-title-filter.pipe';

describe('PostFilterDatePipe', () => {
  it('create an instance', () => {
    const pipe = new PostFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
