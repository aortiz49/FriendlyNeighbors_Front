import { Favor } from './favor';
import { Resident } from '../resident/resident';

export class FavorDetail extends Favor{
  candidates: Resident[];
}
